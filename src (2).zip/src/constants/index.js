// src/constants/index.js
export const APP_NAME = "Orbit Rebuild";
