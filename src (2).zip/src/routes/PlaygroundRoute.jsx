import React from "react";
import PlaygroundApp from "../playground/PlaygroundApp.jsx";
export default function PlaygroundRoute() {
  return <PlaygroundApp />;
}