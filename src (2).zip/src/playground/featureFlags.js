// ======================================================================
// File: src/playground/featureFlags.js
// ======================================================================
export const FLAGS = {
  PLAYGROUND: true, // flip off in prod builds
};